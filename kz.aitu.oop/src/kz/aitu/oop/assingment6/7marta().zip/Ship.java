package kz.aitu.oop.assingment6;

public class Ship implements Transport {

	@Override
	public void deliver() {
		System.out.println("Deliver by sea in a container");
	}

}

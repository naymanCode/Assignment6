package kz.aitu.oop.assingment6;

public interface Transport {
	void deliver();
}

package kz.aitu.oop.assingment5;

public interface Friday {
	boolean isDivisible(int a);

}
